// app/static/js/script.js (novo conteúdo)

document.addEventListener('DOMContentLoaded', function() {
    console.log('script.js do PetBus carregado.');
    // Adicione qualquer funcionalidade JS específica para o PetBus aqui no futuro
});