from bottle import template, request, redirect
from app.models.animal import Animal
from app.models.cliente import Cliente

def listar_animais():
    animais = Animal.listar()
    return template('app/views/html/pet_list', pets=animais)

def mostrar_formulario():
    return template('app/views/html/pet_form', pet=None)

def salvar_animal():
    nome = request.forms.get('nome')
    tipo = request.forms.get('tipo')
    idade = request.forms.get('idade')
    tutor = request.forms.get('tutor')
    Animal.cadastrar(nome, tipo, idade, tutor)
    return redirect('/')

def editar_animal(id):
    animal = Animal.buscar(int(id))
    return template('app/views/html/pet_form', pet=animal)

def atualizar_animal(id):
    nome = request.forms.get('nome')
    tipo = request.forms.get('tipo')
    idade = request.forms.get('idade')
    tutor = request.forms.get('tutor')
    Animal.atualizar(int(id), nome, tipo, idade, tutor)
    return redirect('/')

def deletar_animal(id):
    Animal.deletar(int(id))
    return redirect('/')


from app.models.models import Cliente

def listar_clientes():
    clientes = Cliente.listar()
    return template('app/views/html/cliente_list', clientes=clientes)

def mostrar_formulario_cliente():
    return template('app/views/html/cliente_form', cliente=None)

def salvar_cliente():
    nome = request.forms.get('nome')
    telefone = request.forms.get('telefone')
    endereco = request.forms.get('endereco')
    Cliente.cadastrar(nome, telefone, endereco)
    return redirect('/clientes')

def editar_cliente(id):
    cliente = Cliente.buscar(int(id))
    return template('app/views/html/cliente_form', cliente=cliente)

def atualizar_cliente(id):
    nome = request.forms.get('nome')
    telefone = request.forms.get('telefone')
    endereco = request.forms.get('endereco')
    Cliente.atualizar(int(id), nome, telefone, endereco)
    return redirect('/clientes')

def deletar_cliente(id):
    Cliente.deletar(int(id))
    return redirect('/clientes')
