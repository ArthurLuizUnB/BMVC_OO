class Animal:
    next_id = 1

    def __init__(self, nome, especie, raca, idade, nome_tutor, telefone_tutor, id=None):
        self.id = id if id is not None else Animal.next_id
        if id is None:
            Animal.next_id += 1
        self.nome = nome
        self.especie = especie
        self.raca = raca
        self.idade = idade
        self.nome_tutor = nome_tutor
        self.telefone_tutor = telefone_tutor

    def __repr__(self):
        return f"<Animal {self.id}: {self.nome} ({self.especie})>"

pets = []

pets.append(Animal("Fido", "Cachorro", "Labrador", 3, "João Silva", "99123-4567"))
pets.append(Animal("Miau", "Gato", "Siamês", 2, "Maria Oliveira", "99876-5432"))
pets.append(Animal("Piu", "Pássaro", "Calopsita", 1, "Carlos Souza", "99345-6789"))

if pets:
    Animal.next_id = max(p.id for p in pets) + 1