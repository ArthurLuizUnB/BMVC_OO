# bmvc_projeto/app/routes/route.py

import sys
import os

controllers_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'controllers')
sys.path.insert(0, controllers_path)

from application import app # LINHA 7

if __name__ == '__main__': # LINHA 9
    app.run(debug=True, port=8080) # LINHA 10