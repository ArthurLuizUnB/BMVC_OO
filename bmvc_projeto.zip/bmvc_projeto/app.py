# app.py
from flask import Flask, render_template, request, redirect, url_for
import os # Importar os para funções de caminho, se necessário em outras partes

# Importar as classes de modelo que você criou
from models.animal import Animal
from models.cliente import Cliente
# Pode importar outras classes quando for usá-las:
# from models.veterinario import Veterinario
# from models.consulta import Consulta
# from models.servico import Servico

# Inicializa a aplicação Flask UMA ÚNICA VEZ
app = Flask(__name__,
            template_folder='app/views',  # Define onde o Flask vai procurar os templates (HTML/TPL)
            static_folder='app/static')   # Define onde o Flask vai procurar os arquivos estáticos (CSS, JS, Imagens)

# --- Dados de Exemplo (Temporários, antes do CRUD completo) ---
# Vamos usar listas para simular um "banco de dados" por enquanto.
# Em um CRUD real, estes dados viriam de um banco de dados.

# Criando um cliente de exemplo (apenas um para fins de demonstração)
cliente_exemplo = Cliente(id=1, nome="João da Silva", email="joao@example.com", telefone="99123-4567", endereco="Rua A, 123")

# Lista de animais de exemplo (usando a classe Animal)
# Note que id_cliente é o ID do nosso cliente_exemplo
animals_data = [
    Animal(id=1, nome="Buddy", especie="Cachorro", raca="Golden Retriever", idade=3, peso=25.0, id_cliente=cliente_exemplo.id),
    Animal(id=2, nome="Whiskers", especie="Gato", raca="Siamês", idade=5, peso=4.5, id_cliente=cliente_exemplo.id),
    Animal(id=3, nome="Pingo", especie="Pássaro", raca="Canário", idade=1, peso=0.1, id_cliente=cliente_exemplo.id)
]
next_animal_id = 4 # Próximo ID disponível para novos animais

# --- Rotas do PetBus (CRUD Básico de Animais) ---

# Rota para LISTAR todos os animais
@app.route('/') # Rota inicial, acessa a lista principal
@app.route('/pets', methods=['GET'])
def pet_list():
    # Passamos a lista de objetos Animal para o template
    # Para o template pet_list.html funcionar corretamente com 'pet.nome_tutor' e 'pet.telefone_tutor',
    # precisamos adicionar esses atributos aos objetos Animal antes de passá-los para o template.
    # Em um sistema real, o objeto Animal teria uma referência ao objeto Cliente, e você acessaria assim: pet.cliente.nome.
    # Por simplicidade aqui, vamos adicionar temporariamente esses atributos para a exibição.
    for pet in animals_data:
        # Assumindo que todos os pets pertencem ao cliente_exemplo para esta demo
        pet.nome_tutor = cliente_exemplo.nome
        pet.telefone_tutor = cliente_exemplo.telefone
    return render_template('html/pet_list.html', pets=animals_data, page_title="Lista de Animais")

# Rota para exibir o formulário de ADICIONAR novo animal
@app.route('/pets/new', methods=['GET'])
def pet_new_form():
    # Passamos 'pet=None' para o template saber que é um formulário de adição (não edição)
    return render_template('html/pet_form.html', pet=None, page_title="Adicionar Novo Animal")

# Rota para PROCESSAR o formulário de ADICIONAR/SALVAR animal
@app.route('/pets/save', methods=['POST'])
def pet_new_save():
    global next_animal_id # Indica que vamos modificar a variável global

    # Pega os dados do formulário
    nome = request.form['nome']
    especie = request.form['especie']
    raca = request.form['raca']
    idade = int(request.form['idade'])
    # nome_tutor e telefone_tutor são para o template HTML, mas não salvamos no Animal aqui
    # Em um sistema completo, você buscaria/criaria o Cliente e associaria o Animal a ele.
    # Por agora, eles são apenas para exibir no formulário/lista.

    # Cria um novo objeto Animal
    new_pet = Animal(
        id=next_animal_id,
        nome=nome,
        especie=especie,
        raca=raca,
        idade=idade,
        peso=0.0, # Peso inicial padrão, você pode adicionar ao formulário depois
        id_cliente=cliente_exemplo.id # Associa ao cliente de exemplo fixo
    )

    # Adiciona o novo animal à nossa lista "animals_data"
    animals_data.append(new_pet)
    next_animal_id += 1 # Incrementa o ID para o próximo animal

    print(f"Novo animal adicionado: {new_pet}") # Para debug no terminal

    # Redireciona para a lista de animais após salvar
    return redirect(url_for('pet_list'))

# Rota para exibir o formulário de EDITAR animal
@app.route('/pets/edit/<int:id>', methods=['GET'])
def pet_edit_form(id):
    # Busca o animal pelo ID na nossa lista de dados
    pet_to_edit = next((p for p in animals_data if p.id == id), None)
    if pet_to_edit:
        # Para que o pet_form.html possa exibir o nome e telefone do tutor,
        # vamos adicionar esses atributos temporariamente ao objeto pet_to_edit.
        # Em um sistema real, o objeto Animal teria uma relação com o Cliente, e os dados viriam de lá.
        pet_to_edit.nome_tutor = cliente_exemplo.nome
        pet_to_edit.telefone_tutor = cliente_exemplo.telefone

        return render_template('html/pet_form.html', pet=pet_to_edit, page_title=f"Editar {pet_to_edit.nome}")
    else:
        return "Animal não encontrado", 404

# Rota para PROCESSAR o formulário de EDITAR/SALVAR animal
@app.route('/pets/edit/save/<int:id>', methods=['POST'])
def pet_edit_save(id):
    # Encontra o animal a ser editado
    pet_to_update = next((p for p in animals_data if p.id == id), None)
    if pet_to_update:
        # Atualiza os atributos do objeto Animal com os dados do formulário
        pet_to_update.nome = request.form['nome']
        pet_to_update.especie = request.form['especie']
        pet_to_update.raca = request.form['raca']
        pet_to_update.idade = int(request.form['idade'])
        # nome_tutor e telefone_tutor seriam atualizados no objeto Cliente (não no Animal)
        # por simplicidade, não fazemos nada com eles aqui pois estamos mockando dados
        
        print(f"Animal atualizado: {pet_to_update}") # Para debug no terminal
        return redirect(url_for('pet_list'))
    else:
        return "Animal não encontrado para atualização", 404

# Rota para EXCLUIR animal
@app.route('/pets/delete/<int:id>', methods=['GET'])
def pet_delete(id):
    global animals_data # Indica que vamos modificar a lista global
    original_len = len(animals_data)
    # Filtra o animal a ser excluído criando uma nova lista sem ele
    animals_data = [p for p in animals_data if p.id != id] 

    if len(animals_data) < original_len:
        print(f"Animal com ID {id} excluído.") # Para debug
    else:
        print(f"Animal com ID {id} não encontrado para exclusão.") # Para debug

    return redirect(url_for('pet_list')) # Redireciona de volta para a lista

# Inicia o servidor Flask se o script for executado diretamente
if __name__ == '__main__':
    app.run(debug=True) # debug=True ativa o modo de depuração (recarrega ao salvar, mostra erros)